REVOUGE – TWO SITES

PRIVATE (admin.html)  – stays on your computer. NEVER upload it.
PUBLIC  (public folder) – the shop everyone sees. This is the only thing you upload.

CHANGING THE SHOP
1. Open admin.html (double-click it).
2. Change prices, buy links, add/remove items.
3. Press "Save shop-data.js". Move that file into the public folder, replacing the old one.
4. Upload the public folder again (Netlify: drag it onto your site's Deploys page).

GOING ONLINE (free)
1. Go to netlify.com, sign up, and drag the public folder onto "Deploy manually".
2. Choose a site name like revouge -> you get revouge.netlify.app
3. Replace YOURDOMAIN.com in public/index.html, robots.txt and sitemap.xml with that address, upload again.
4. Add the site in Google Search Console, submit /sitemap.xml and request indexing.

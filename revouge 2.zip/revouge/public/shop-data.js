const CONFIG = {
  "items": [
    { "emoji": "👗", "name": "Vintage silk dress", "desc": "Size M, worn twice, great condition.", "price": 45, "link": "", "sold": false },
    { "emoji": "👜", "name": "Leather handbag", "desc": "Classic brown, small scuffs.", "price": 60, "link": "", "sold": false },
    { "emoji": "🧥", "name": "Wool coat", "desc": "Size L, very warm.", "price": 80, "link": "", "sold": false }
  ]
};
